# Getting Started with BLDC Project
The BLDC tool/app provide a reactjs based frontend application on top of electron framework. This application works as standalone application.

## Available Scripts

In the project directory, you can run:

### `npm run build:web`
This will build the react application


Runs the app in the web mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

### `npm run start:web`

Run the app in standalone mode

### `npm run start:desktop`


