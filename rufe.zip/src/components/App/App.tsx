import DashboardConatiner from "../common";
import "./App.scss";
function App() {
  return <DashboardConatiner />;
}

export default App;
